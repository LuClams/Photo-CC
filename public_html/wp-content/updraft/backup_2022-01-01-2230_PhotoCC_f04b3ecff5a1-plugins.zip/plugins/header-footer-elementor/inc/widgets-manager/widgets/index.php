<?php
/**
 * Silence is golden.
