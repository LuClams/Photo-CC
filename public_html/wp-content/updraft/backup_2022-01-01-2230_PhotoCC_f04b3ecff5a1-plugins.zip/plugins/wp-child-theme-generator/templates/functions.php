<?php echo "<?php", "\n"; ?>
/**
 * Recommended way to include parent theme styles.
 * (Please see http://codex.wordpress.org/Child_Themes#How_to_Create_a_Child_Theme)
 *
 */  

<?php echo $function, "\n"; ?>

/**
 * Your code goes below.
 */

