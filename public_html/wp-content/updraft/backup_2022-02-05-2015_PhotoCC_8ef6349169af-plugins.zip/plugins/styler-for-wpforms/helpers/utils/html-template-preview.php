<div class="sfwf-preview" id="sfwf-preview" style="width:80%; margin:auto; margin-top: 80px;">
	<?php echo do_shortcode( '[wpforms id="' . $form_id . '" title="true" description="true"  ]' ); ?>
</div>
