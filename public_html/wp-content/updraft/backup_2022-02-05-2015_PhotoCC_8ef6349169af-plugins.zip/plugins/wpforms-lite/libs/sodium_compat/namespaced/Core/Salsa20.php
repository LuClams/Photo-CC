<?php
namespace ParagonIE\Sodium\Core;

class Salsa20 extends \ParagonIE_Sodium_Core_Salsa20
{

}
